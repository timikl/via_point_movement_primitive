#include <mplib/plot/GNUPlot.h>

#include <mplib/math/function_approximation/LocallyWeightedRegression.h>
#include <mplib/math/util/vector_arithmetic.h>

mplib::core::DVec2d toDVec2d(const mplib::core::DVec &vec)
{
    mplib::core::DVec2d vec2d;
    for (unsigned int i = 0; i < vec.size(); i++)
    {
        vec2d.push_back(mplib::core::DVec{ vec[i] });
    }
    return vec2d;
}

int main(int argc, char* argv[])
{
    using namespace mplib::core;

    const unsigned int num_kernels = 50;
    const unsigned int num_samples = 100;

    DVec x;
    DVec y;
    for (unsigned int i = 0; i < num_samples; i++)
    {
        double u = (double)i / (num_samples-1);
        x.push_back(u);
        y.push_back(sin(2 * M_PI * u));
    }


    // Compute approximated trajectories
    std::vector<double> outRangeKernels = { 0.0, 0.1, 0.2 };
    std::vector<DVec> y_approximation;
    std::vector<DVec> weights;
    for (double outRangeKernel : outRangeKernels)
    {
        auto approx = mplib::math::function_approximation::LocallyWeightedRegression(num_kernels, 1, false, outRangeKernel);
        approx.learn(toDVec2d(x), toDVec2d(y));

        DVec _y;
        for (double value : x)
        {
            _y.push_back(approx(DVec{value})[0]);
        }
        y_approximation.push_back(_y);
        weights.push_back(approx.getWeights());
    }


    KILL_ALL_PLOT_WINDOWS;
    mplib::plot::GNUPlot plt;
    std::vector<std::string> colors{"#5BB727", "#F5B041", "#2980B9", "#000000"};

    // Plot values
    plt.clear();
    for (unsigned int i = 0; i < outRangeKernels.size(); i++)
    {
        plt.plotLine(x, y_approximation[i], "Out range kernel: " + std::to_string(outRangeKernels[i]), colors[i]);
    }
    plt.plotLine(x, y, "Original trajectory", colors[outRangeKernels.size()], mplib::plot::GNUPlot::LineType::Dash);
    plt.show();

    // Plot weights
    plt.clear();
    for (unsigned int i = 0; i < outRangeKernels.size(); i++)
    {
        DVec x_weights;
        for (unsigned int j = 0; j < weights[i].size(); j++)
        {
            x_weights.push_back((double)j / (weights[i].size()-1));
        }
        plt.plotLine(x_weights, weights[i], "Out range kernel: " + std::to_string(outRangeKernels[i]), colors[i]);
    }
    plt.show();
}
