#include "CovarianceFunction.h"

namespace mplib::math::kernel
{

    CovarianceFunction::~CovarianceFunction() = default;

}
